CHIRAG PHOTOGRAPHY WEBSITE

1. Open index.html in a browser to preview the website.
2. Keep the assets folder beside index.html when uploading.
3. Upload the complete chirag_photography_website folder contents to your hosting provider.
4. The homepage background is homepage-background.jpg.
5. The seven supplied photographs are used in the portfolio gallery.
6. The gallery watermark is a website overlay; the original image files are kept unchanged.
7. Replace the enquiry email address in index.html with your real business email before publishing.
